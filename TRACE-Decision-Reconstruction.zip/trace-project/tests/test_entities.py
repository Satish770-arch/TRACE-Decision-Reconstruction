from app.main import extract_entities

def test_extracts_dates_and_name_suggestions():
    result = extract_entities('Meeting with Priya Sharma on 2026-11-08 about the internship.')
    assert '2026-11-08' in result['date_mentions']
    assert 'Priya Sharma' in result['name_suggestions']

def test_empty_text_is_safe():
    assert extract_entities('') == {'date_mentions': [], 'name_suggestions': []}

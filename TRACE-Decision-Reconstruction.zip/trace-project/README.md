# TRACE — The Invisible Story Engine

**A local-first decision reconstruction prototype.** TRACE stores evidence, lets you record decisions with their rationale and outcomes, and builds an inspectable timeline plus a graph of explicitly linked records. It also surfaces *possible* connections from shared name-like phrases; these are suggestions, never treated as facts.

> Originality note: TRACE is a project concept and implementation, not a claim that no similar product or research exists. Its distinctive prototype focus is evidence-linked decision reconstruction with a clear separation between confirmed links and heuristic suggestions.

## Features
- Evidence vault for notes, emails, document summaries, screenshot descriptions and conversations.
- Chronological timeline with source and timestamp metadata.
- Decision journal with rationale, outcome and links to supporting evidence.
- Connection map for confirmed evidence-to-decision links.
- Transparent possible-connection suggestions from repeated capitalized phrases.
- Import `.txt` and `.md` files (1 MB maximum).
- Export all records to JSON.
- Local SQLite storage; no account, cloud service or external AI API required.
- Interactive API docs at `/docs`.

## Quick start
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000 . API docs: http://127.0.0.1:8000/docs

Alternatively run `./run.sh` on macOS/Linux.

## Example workflow
1. Add evidence: `First internship application`, paste the email text, set source type to Email.
2. Add another record: `Interview invitation`, paste the relevant details.
3. Record a decision: `Prepare for the interview`, explain why, and select both evidence items.
4. Inspect the timeline and connection map. The solid relationship means you linked the records yourself. Dashed amber suggestions are heuristic and require human review.
5. Export your archive periodically.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET/POST | `/api/items` | List / add evidence |
| DELETE | `/api/items/{id}` | Delete evidence |
| POST | `/api/import-text` | Import TXT or Markdown |
| GET/POST | `/api/decisions` | List / record decisions |
| GET | `/api/graph` | Graph nodes, confirmed edges and suggestions |
| GET | `/api/export` | Export archive JSON |

## Architecture
- **Frontend:** vanilla HTML, CSS and JavaScript.
- **Backend:** FastAPI + Pydantic.
- **Storage:** SQLite.
- **Extraction:** transparent regex heuristics for date mentions and name-like phrases.

## Privacy and limitations
- Data is stored in `data/trace.db` on the machine running the server. Do not expose this development server to the public internet without authentication, authorization, HTTPS and deployment hardening.
- This starter does not use a hosted LLM. It does not infer intent, causality or true identity. Extracted dates/names and possible connections are suggestions only.
- File import currently supports TXT and Markdown; PDF/OCR and image parsing are planned extensions.
- No authentication/multi-user support is included in this prototype.

## Roadmap
1. Add PDF text extraction and OCR with explicit source citations.
2. Add user-reviewed entity resolution and editable graph edges.
3. Add semantic search using local embeddings.
4. Add optional local language model for decision summaries with evidence citations.
5. Add authentication, encrypted backups and audit history before any hosted deployment.

## License
MIT — see [LICENSE](LICENSE).

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
from datetime import datetime, timezone
import sqlite3, json, re, uuid

ROOT = Path(__file__).resolve().parent.parent
DB = ROOT / 'data' / 'trace.db'
app = FastAPI(title='TRACE — Decision Reconstruction Engine', version='1.0.0', description='Turn scattered notes into an evidence-linked timeline and decision map.')
app.mount('/static', StaticFiles(directory=ROOT / 'static'), name='static')

class ItemIn(BaseModel):
    title: str = Field(min_length=2, max_length=180)
    content: str = Field(min_length=3, max_length=30000)
    source_type: str = 'note'
    source_name: str = 'Manual note'
    occurred_at: str | None = None
    tags: list[str] = []

class DecisionIn(BaseModel):
    title: str
    rationale: str = ''
    outcome: str = ''
    item_ids: list[int] = []


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

@app.on_event('startup')
def startup():
    DB.parent.mkdir(exist_ok=True)
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL, source_type TEXT NOT NULL, source_name TEXT NOT NULL, occurred_at TEXT NOT NULL, created_at TEXT NOT NULL, tags TEXT NOT NULL, entities TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, rationale TEXT NOT NULL, outcome TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS decision_items(decision_id INTEGER, item_id INTEGER, PRIMARY KEY(decision_id,item_id));
        ''')

@app.get('/')
def home(): return FileResponse(ROOT / 'static' / 'index.html')

@app.get('/api/health')
def health(): return {'status':'ok','product':'TRACE','version':'1.0.0'}

# Transparent extraction: dates and capitalized phrases are suggestions, not verified facts.
def extract_entities(text):
    dates = re.findall(r'\b(?:\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4})\b', text)
    names = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2}\b', text)
    stop = {'The','This','That','When','What','I','We','My','Our','On','At','For','From','After','Before'}
    names = list(dict.fromkeys(x for x in names if x.split()[0] not in stop))[:12]
    return {'date_mentions':list(dict.fromkeys(dates)), 'name_suggestions':names}

@app.post('/api/items')
def add_item(item: ItemIn):
    now = datetime.now(timezone.utc).isoformat()
    occurred = item.occurred_at or now
    entities = extract_entities(item.title + '\n' + item.content)
    with db() as c:
        cur = c.execute('INSERT INTO items(title,content,source_type,source_name,occurred_at,created_at,tags,entities) VALUES(?,?,?,?,?,?,?,?)',
          (item.title,item.content,item.source_type,item.source_name,occurred,now,json.dumps(item.tags),json.dumps(entities)))
        row = c.execute('SELECT * FROM items WHERE id=?',(cur.lastrowid,)).fetchone()
    return serialize_item(row)

@app.get('/api/items')
def list_items():
    with db() as c: rows = c.execute('SELECT * FROM items ORDER BY occurred_at DESC, id DESC').fetchall()
    return [serialize_item(r) for r in rows]

def serialize_item(r):
    d = dict(r); d['tags']=json.loads(d['tags']); d['entities']=json.loads(d['entities']); return d

@app.delete('/api/items/{item_id}')
def delete_item(item_id:int):
    with db() as c:
        c.execute('DELETE FROM decision_items WHERE item_id=?',(item_id,)); cur=c.execute('DELETE FROM items WHERE id=?',(item_id,))
    if not cur.rowcount: raise HTTPException(404,'Evidence item not found')
    return {'deleted':item_id}

@app.post('/api/decisions')
def add_decision(d: DecisionIn):
    now=datetime.now(timezone.utc).isoformat()
    with db() as c:
        cur=c.execute('INSERT INTO decisions(title,rationale,outcome,created_at) VALUES(?,?,?,?)',(d.title,d.rationale,d.outcome,now))
        did=cur.lastrowid
        for iid in d.item_ids:
            if not c.execute('SELECT id FROM items WHERE id=?',(iid,)).fetchone(): raise HTTPException(400,f'Unknown evidence item: {iid}')
            c.execute('INSERT OR IGNORE INTO decision_items VALUES(?,?)',(did,iid))
    return {'id':did,'title':d.title,'rationale':d.rationale,'outcome':d.outcome,'created_at':now,'item_ids':d.item_ids}

@app.get('/api/decisions')
def list_decisions():
    with db() as c:
        ds=c.execute('SELECT * FROM decisions ORDER BY created_at DESC').fetchall()
        out=[]
        for d in ds:
            ids=[x['item_id'] for x in c.execute('SELECT item_id FROM decision_items WHERE decision_id=?',(d['id'],)).fetchall()]
            out.append({**dict(d),'item_ids':ids})
    return out

@app.get('/api/graph')
def graph():
    with db() as c:
        items=[serialize_item(r) for r in c.execute('SELECT * FROM items').fetchall()]
        decisions=[dict(r) for r in c.execute('SELECT * FROM decisions').fetchall()]
        links=[dict(r) for r in c.execute('SELECT * FROM decision_items').fetchall()]
    nodes=[{'id':f"item-{i['id']}",'label':i['title'],'kind':'evidence','date':i['occurred_at']} for i in items]
    nodes += [{'id':f"decision-{d['id']}",'label':d['title'],'kind':'decision','date':d['created_at']} for d in decisions]
    edges=[{'from':f"item-{x['item_id']}",'to':f"decision-{x['decision_id']}",'label':'supports'} for x in links]
    # Suggest possible links by shared extracted names; never create them as confirmed relationships.
    suggestions=[]
    for a_idx,a in enumerate(items):
        a_names=set(a['entities']['name_suggestions'])
        for b in items[a_idx+1:]:
            shared=a_names & set(b['entities']['name_suggestions'])
            if shared: suggestions.append({'from':f"item-{a['id']}",'to':f"item-{b['id']}",'label':'possible connection','shared_terms':sorted(shared)})
    return {'nodes':nodes,'edges':edges,'suggestions':suggestions}

@app.post('/api/import-text')
async def import_text(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(('.txt','.md')): raise HTTPException(415,'For this starter version, upload .txt or .md files. PDF extraction can be added next.')
    raw=await file.read()
    if len(raw)>1_000_000: raise HTTPException(413,'File is larger than 1 MB')
    content=raw.decode('utf-8',errors='replace').strip()
    if not content: raise HTTPException(400,'The file is empty')
    title=Path(file.filename).stem.replace('_',' ').replace('-',' ').title()
    return add_item(ItemIn(title=title,content=content,source_type='file',source_name=file.filename))

@app.get('/api/export')
def export_data():
    with db() as c:
        items=[serialize_item(r) for r in c.execute('SELECT * FROM items').fetchall()]
        decisions=list_decisions()
    return {'product':'TRACE','exported_at':datetime.now(timezone.utc).isoformat(),'items':items,'decisions':decisions}
